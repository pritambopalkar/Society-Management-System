package com.example.myapplication.Activity.Flat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import com.example.myapplication.Adapter.FlatAdapter;
import com.example.myapplication.R;

import java.util.ArrayList;

public class FlatActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flat);

        // Find the Toolbar by its ID
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set the title of the Toolbar
        getSupportActionBar().setTitle("Flat List");

        // Find the RecyclerView by its ID
        recyclerView = findViewById(R.id.recyclerViewFlat);

        // Create and set up the layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Define your dataset (example)
        ArrayList<String> flatData = new ArrayList<>();
        flatData.add("Flat 1");
        flatData.add("Flat 2");
        flatData.add("Flat 3");
        flatData.add("Flat 4");

        // Create and set up the adapter with the dataset
        FlatAdapter adapter = new FlatAdapter(flatData);
        recyclerView.setAdapter(adapter);
    }
}
