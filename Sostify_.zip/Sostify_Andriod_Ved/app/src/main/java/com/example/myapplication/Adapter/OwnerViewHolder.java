package com.example.myapplication.Adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class OwnerViewHolder extends RecyclerView.ViewHolder {
    public TextView textViewName;
    public TextView textViewAddress;

    public OwnerViewHolder(@NonNull View itemView) {
        super(itemView);
        textViewName = itemView.findViewById(R.id.textViewName);
        textViewAddress = itemView.findViewById(R.id.textViewAddress);
    }
}
