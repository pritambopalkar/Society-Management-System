package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;

import com.example.myapplication.R;



import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class AddAnnouncementActivity extends AppCompatActivity {

    EditText etAnnouncement;
    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_announcement);

        // Initialize EditText
        etAnnouncement = findViewById(R.id.etAnnouncement);

        // Initialize Button
        submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get announcement text from EditText
                String announcement = etAnnouncement.getText().toString();

                // Check if announcement is empty
                if (announcement.trim().isEmpty()) {
                    // If announcement is empty, show an error message
                    etAnnouncement.setError("Please enter an announcement");
                } else {
                    // If announcement is not empty, proceed with submission
                    // You can perform any action with the announcement here, like sending it to server, etc.

                    // Start AnnouncementActivity
                    Intent intent = new Intent(AddAnnouncementActivity.this, AnnouncementActivity.class);
                    // Pass any data if needed
                    intent.putExtra("announcement", announcement);
                    startActivity(intent);

                    // Finish the current activity if you don't want to go back to it
                    finish();
                }
            }
        });


    }
}
