package com.example.myapplication.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.Pojo.Society;
import com.example.myapplication.R;
import java.util.List;
public class SocietyAdapter extends RecyclerView.Adapter<SocietyAdapter.SocietyViewHolder> {

    private List<Society> societyList;

    public SocietyAdapter(List<Society> societyList) {
        this.societyList = societyList;
    }

    @NonNull
    @Override
    public SocietyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_society, parent, false);
        return new SocietyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SocietyViewHolder holder, int position) {
        Society society = societyList.get(position);
        holder.bind(society);
    }

    @Override
    public int getItemCount() {
        return societyList.size();
    }

    static class SocietyViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewAddress,textViewName;

        SocietyViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewAddress = itemView.findViewById(R.id.textViewAddress);
        }

        void bind(Society society) {

            textViewName.setText(society.getName());
            textViewAddress.setText(society.getAddress());
        }
    }
}
