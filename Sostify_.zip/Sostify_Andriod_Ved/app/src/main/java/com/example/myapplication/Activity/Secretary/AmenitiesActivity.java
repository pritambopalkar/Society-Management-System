package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import com.example.myapplication.Adapter.AmenitiesAdapter;
import com.example.myapplication.R;
import java.util.ArrayList;

public class AmenitiesActivity extends AppCompatActivity {

    private Toolbar toolbar; // Declare Toolbar variable
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amenities);

        // Find the Toolbar by its ID
        toolbar = findViewById(R.id.toolbar);

        // Set the Toolbar as the SupportActionBar
        setSupportActionBar(toolbar);

        // Set the title of the Toolbar
        getSupportActionBar().setTitle("Amenities List");

        // Find the RecyclerView by its ID
        recyclerView = findViewById(R.id.recyclerViewAmenities);

        // Create and set up the layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Define your dataset (example)
        ArrayList<String> amenitiesData = new ArrayList<>();
        amenitiesData.add("Amenity 1");
        amenitiesData.add("Amenity 2");
        amenitiesData.add("Amenity 3");
        amenitiesData.add("Amenity 4");

        // Create and set up the adapter with the dataset
        AmenitiesAdapter adapter = new AmenitiesAdapter(amenitiesData);
        recyclerView.setAdapter(adapter);
    }
}
