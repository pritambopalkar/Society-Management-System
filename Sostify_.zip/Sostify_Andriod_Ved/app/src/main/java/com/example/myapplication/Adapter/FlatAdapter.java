// FlatAdapter.java

package com.example.myapplication.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.myapplication.R;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class FlatAdapter extends RecyclerView.Adapter<FlatAdapter.FlatViewHolder> {

    private ArrayList<String> dataSet; // Updated to ArrayList

    // Constructor to initialize the data set
    public FlatAdapter(ArrayList<String> dataSet) {
        this.dataSet = dataSet;
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public FlatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_flat, parent, false);
        return new FlatViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull FlatViewHolder holder, int position) {
        // Get element from your data set at this position
        // Replace it with the content of the view
        holder.textView.setText(dataSet.get(position)); // Use get() method for ArrayList
    }

    // Return the size of your data set (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return dataSet.size(); // Use size() method for ArrayList
    }

    // Provide a reference to the views for each data item
    public static class FlatViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        public FlatViewHolder(View view) {
            super(view);
            textView = view.findViewById(R.id.textView);
        }
    }
}
