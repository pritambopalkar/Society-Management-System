package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.Activity.AdminActivity;
import com.example.myapplication.Activity.LoginActivity;
import com.example.myapplication.Pojo.Secretary;
import com.example.myapplication.R;
import com.example.myapplication.Retro.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddSecretaryActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail, editTextMobileNo, editTextPassword, editTextConfirmPassword, editTextSocietyId;
    private Button buttonSave;

     String name,email,mobileNo,password,societyId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_secretary);

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextMobileNo = findViewById(R.id.editTextMobileNo);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editTextSocietyId = findViewById(R.id.editTextSocietyId);
        buttonSave = findViewById(R.id.buttonSave);

        // Set click listener for Save button
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate input fields
                if (isValidInput()) {
                    // If input is valid, perform the save operation
                    saveSecretary();
                }
            }
        });
    }

    // Method to validate input fields
    private boolean isValidInput() {
         name = editTextName.getText().toString().trim();
         email = editTextEmail.getText().toString().trim();
         mobileNo = editTextMobileNo.getText().toString().trim();
         password = editTextPassword.getText().toString().trim();
         String confirmPassword = editTextConfirmPassword.getText().toString().trim();
         societyId = editTextSocietyId.getText().toString().trim();

        // Check if any of the fields are empty
        if (TextUtils.isEmpty(name)) {
            showToast("Please enter name");
            return false;
        } else if (TextUtils.isEmpty(email)) {
            showToast("Please enter email");
            return false;
        } else if (TextUtils.isEmpty(mobileNo)) {
            showToast("Please enter mobile number");
            return false;
        }  else if (TextUtils.isEmpty(password)) {
            showToast("Please enter password");
            return false;
        } else if (TextUtils.isEmpty(confirmPassword)) {
            showToast("Please confirm password");
            return false;
        } else if (!password.equals(confirmPassword)) {
            showToast("Passwords do not match");
            return false;
        } else if (TextUtils.isEmpty(societyId)) {
            showToast("Please enter SocietyId");
            return false;
        }
        return true;
    }



    // Method to perform save operation
    private void saveSecretary() {
        // Perform the save operation here
        // This is just a placeholder method
        showToast("Secretary saved successfully");
        // You can add code here to save the secretary data to a database or perform other operations
        // For demonstration purposes, we are just displaying a toast message


        Secretary s1=new Secretary(societyId,name,email,mobileNo,password);

        Log.e("wwwwwwwwwwwwwwwwwwwww",s1.toString());
        RetrofitClient.getInstance().getApi().addSecretary(s1).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.d("addsociety", "onResponse: " + response.body());
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject body = response.body();
                    if (body.has("status") && body.get("status").getAsString().equals("success")) {
                        showToast("Secretary saved successfully");
                        Intent intent = new Intent(AddSecretaryActivity.this, LoginActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(AddSecretaryActivity.this, "Failed to save secretary", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(AddSecretaryActivity.this, "Network Issue", Toast.LENGTH_LONG).show();
                }
            }


            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("addsociety","onFailure"+t.getLocalizedMessage());
            }
        });


    }

    // Method to show toast messages
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
