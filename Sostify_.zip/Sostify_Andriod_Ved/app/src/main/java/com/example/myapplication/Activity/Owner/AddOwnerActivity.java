package com.example.myapplication.Activity.Owner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class AddOwnerActivity extends AppCompatActivity {


    private EditText editTextFlatNo, editTextName, editTextAddress, editTextMobileNo, editTextEmail, editTextPassword, editTextPassword2;
    private Button buttonAddOwner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_owner);

        editTextFlatNo = findViewById(R.id.editTextFlatNo);
        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextMobileNo = findViewById(R.id.editTextMobileNo);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextPassword2 = findViewById(R.id.editTextPassword2);
        buttonAddOwner = findViewById(R.id.buttonAddOwner);

        // Setting click listener for the button
        buttonAddOwner.setOnClickListener(v -> addOwner());
    }

    private void addOwner() {
        // Array of EditText fields
        EditText[] editTexts = {editTextFlatNo, editTextName, editTextAddress, editTextMobileNo, editTextEmail, editTextPassword, editTextPassword2};

        // Iterate over EditText fields
        for (EditText editText : editTexts) {
            // Check if any field is empty
            if (editText.getText().toString().trim().isEmpty()) {
                editText.setError("This field is required");
                editText.requestFocus();
                return;
            }
        }

        // Retrieve input values
        String flatNo = editTextFlatNo.getText().toString().trim();
        String name = editTextName.getText().toString().trim();
        String address = editTextAddress.getText().toString().trim();
        String mobileNo = editTextMobileNo.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String password2 = editTextPassword2.getText().toString().trim();

        // Check if email is valid
        if (email.isEmpty()) {
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }

        if (password2.isEmpty()) {
            editTextPassword2.setError("Confirm password is required");
            editTextPassword2.requestFocus();
            return;
        }


        if (!password.equals(password2)) {
            editTextPassword2.setError("Passwords do not match");
            editTextPassword2.requestFocus();
            return;
        }

        Intent intent=new Intent(this, OwnerListActivity.class);
        startActivity(intent);
    }

}