package com.example.myapplication.Pojo;

public class Service {
    private String serviceName;
    private String servicePerson;

    public Service(String serviceName, String servicePerson) {
        this.serviceName = serviceName;
        this.servicePerson = servicePerson;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getServicePerson() {
        return servicePerson;
    }
}
