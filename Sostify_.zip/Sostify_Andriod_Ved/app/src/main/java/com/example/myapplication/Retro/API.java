package com.example.myapplication.Retro;

import com.example.myapplication.Pojo.Credentials;
import com.example.myapplication.Pojo.Secretary;
import com.example.myapplication.Pojo.Society;
import com.google.gson.JsonObject;


import retrofit2.Call;

import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface API {

    public static final String BASE_URL="http://192.168.134.249:9898";
    @GET("/society")
    Call<JsonObject> getSocieties();

    @POST("/society/addSociety")
    Call<JsonObject> addSociety(@Body Society s1);

    @POST("/secretary/registerSecretary")
    Call<JsonObject> addSecretary(@Body Secretary s1);

    @POST("/secretary/loginSecretary")
    Call<JsonObject> loginSecretary(@Body Credentials cr);
}


