// OwnerListActivity.java
package com.example.myapplication.Activity.Owner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.Adapter.OwnerAdapter;
import com.example.myapplication.Pojo.Owner;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class OwnerListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private OwnerAdapter ownerAdapter;
    private List<Owner> ownerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_list);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerViewOwnerList);

        // Set layout manager to RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize owner list
        ownerList = new ArrayList<>();
        ownerList.add(new Owner("John Doe", "123 Main St"));
        ownerList.add(new Owner("Jane Smith", "456 Elm St"));

        // Initialize adapter and set it to RecyclerView
        ownerAdapter = new OwnerAdapter(this, ownerList);
        recyclerView.setAdapter(ownerAdapter);
    }
}
