package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.myapplication.R;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddServicesActivity extends AppCompatActivity {

    private EditText editTextServiceName, editTextServicePerson;
    private Button buttonAddService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_services);

        // Initialize views
        editTextServiceName = findViewById(R.id.editTextServiceName);
        editTextServicePerson = findViewById(R.id.editTextServicePerson);
        buttonAddService = findViewById(R.id.buttonAddService);

        // Set click listener for Add Service button
        buttonAddService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addService();
            }
        });
    }

    private void addService() {
        // Get input values
        String serviceName = editTextServiceName.getText().toString().trim();
        String servicePerson = editTextServicePerson.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(serviceName)) {
            editTextServiceName.setError("Service name is required");
            editTextServiceName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(servicePerson)) {
            editTextServicePerson.setError("Service person name is required");
            editTextServicePerson.requestFocus();
            return;
        }



        // Perform addition of service (database insertion or other logic)
        // For now, let's just display a toast message
        Toast.makeText(this, "Service added successfully", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this,ServiceListActivity.class));
    }
}
