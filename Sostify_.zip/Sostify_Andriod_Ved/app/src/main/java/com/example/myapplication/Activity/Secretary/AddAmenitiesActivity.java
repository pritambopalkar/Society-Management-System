package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.R;

public class AddAmenitiesActivity extends AppCompatActivity {

    EditText etAmenityDescription;
    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_amenities);

        // Initialize EditText field for description only
        etAmenityDescription = findViewById(R.id.etAmenityDescription);

        // Initialize submit button
        submitButton = findViewById(R.id.submitButton);

      submitButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get inputted amenity description
                    String amenityDescription = etAmenityDescription.getText().toString().trim();

                    // Validate input
                    if (amenityDescription.isEmpty()) {
                        // Display toast message if the description field is empty
                        Toast.makeText(AddAmenitiesActivity.this, "Please enter amenity description", Toast.LENGTH_SHORT).show();
                    } else {
                        // Proceed with adding the amenity
                        // You can perform any action here, such as saving to database
                        // For now, just displaying a toast message
                        Toast.makeText(AddAmenitiesActivity.this, "Amenity added successfully", Toast.LENGTH_SHORT).show();
                        // Start AmenitiesActivity
                        startActivity(new Intent(AddAmenitiesActivity.this, AmenitiesActivity.class));
                        // Optionally, you can finish the activity
                        finish();
                    }
                }
            });

        }
}
