package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.Adapter.AnnouncementAdapter;
import com.example.myapplication.R;

import java.util.ArrayList;

public class AnnouncementActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcement);

        // Find the Toolbar by its ID
        toolbar = findViewById(R.id.toolbar);

        // Set the Toolbar as the SupportActionBar
        setSupportActionBar(toolbar);

        // Set the title of the Toolbar
        getSupportActionBar().setTitle("Announcement List");

        // Find the RecyclerView by its ID
        recyclerView = findViewById(R.id.recyclerViewAnnouncement);

        // Create and set up the layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Define your dataset (example)
        ArrayList<String> announcementData = new ArrayList<>();
        announcementData.add("Announcement 1");
        announcementData.add("Announcement 2");
        announcementData.add("Announcement 3");
        announcementData.add("Announcement 4");

        // Create and set up the adapter with the dataset
        AnnouncementAdapter adapter = new AnnouncementAdapter(announcementData);
        recyclerView.setAdapter(adapter);
    }
}
