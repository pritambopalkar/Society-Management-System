// ServiceListActivity.java
package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication.Adapter.ServiceAdapter;
import com.example.myapplication.Pojo.Service;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class ServiceListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ServiceAdapter serviceAdapter;
    private List<Service> serviceList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);

        // Set layout manager to RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize service list
        serviceList = new ArrayList<>();
        serviceList.add(new Service("Plumber", "John Doe"));
        serviceList.add(new Service("Electrician", "Jane Smith"));

        // Initialize adapter and set it to RecyclerView
        serviceAdapter = new ServiceAdapter(this, serviceList);
        recyclerView.setAdapter(serviceAdapter);
    }
}
