package com.example.myapplication.Activity.Secretary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import com.example.myapplication.Activity.Flat.FlatActivity;
import com.example.myapplication.Activity.Owner.AddOwnerActivity;
import com.example.myapplication.R;



public class SecretaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secretary_activity);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Admin Panel");

        // Fetch ImageView elements from CardViews
        ImageView imageView1 = findViewById(R.id.imageView1);
        ImageView imageView2 = findViewById(R.id.imageView2);
        ImageView imageView3 = findViewById(R.id.imageView3);
        ImageView imageView4 = findViewById(R.id.imageView4);

        // Set click listeners on ImageViews
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for ImageView 1
                Intent intent = new Intent(SecretaryActivity.this, FlatActivity.class);
                startActivity(intent);
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for ImageView 2
                startActivity(new Intent(SecretaryActivity.this, AmenitiesActivity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for ImageView 3
                startActivity(new Intent(SecretaryActivity.this, AnnouncementActivity.class));
            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for ImageView 4
                // No action specified for CardView 4 in your code
            }
        });
    }
    // Rest of your code...
}
