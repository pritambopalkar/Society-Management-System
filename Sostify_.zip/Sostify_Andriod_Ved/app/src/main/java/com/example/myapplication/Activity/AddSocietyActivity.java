package com.example.myapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Pojo.Society;
import com.example.myapplication.R;
import com.example.myapplication.Retro.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddSocietyActivity extends AppCompatActivity {

    private EditText editTextName, editTextAddress;
    private Button buttonAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_society);

        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        buttonAdd = findViewById(R.id.buttonAdd);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSociety();
            }
        });
    }

    private void addSociety() {
        // Get the values from EditText fields
        String name = editTextName.getText().toString().trim();
        String address = editTextAddress.getText().toString().trim();

        // Perform validation
        if (name.isEmpty()) {
            editTextName.setError("Please enter a society name");
            editTextName.requestFocus();
            return; // Stop further execution
        }

        if (address.isEmpty()) {
            editTextAddress.setError("Please enter a society address");
            editTextAddress.requestFocus();
            return; // Stop further execution
        }

        // If validation passes, create an intent to pass back the data to the AdminActivity

        Society s1=new Society(name,address);
        RetrofitClient.getInstance().getApi().addSociety(s1).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.d("addsociety", "onResponse: "+response.body());
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("addsociety","onFailure"+t.getLocalizedMessage());
            }
        });



        finish(); // Close the AddSocietyActivity
    }

}
