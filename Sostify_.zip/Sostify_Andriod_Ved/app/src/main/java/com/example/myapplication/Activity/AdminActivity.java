package com.example.myapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Activity.Secretary.AddSecretaryActivity;
import com.example.myapplication.Adapter.SocietyAdapter;
import com.example.myapplication.Pojo.Society;
import com.example.myapplication.R;
import com.example.myapplication.Retro.API;
import com.example.myapplication.Retro.RetrofitClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminActivity extends AppCompatActivity {

    private TextView society_count;
    private RecyclerView recyclerViewSocieties;
    private SocietyAdapter adapter;
    private List<Society> societyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        society_count=findViewById(R.id.society_count);

        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Add back button
        getSupportActionBar().setTitle("Admin Dashboard"); // Set title

        // Set up logo icon programmatically
        ImageView logoImageView = new ImageView(this);
        logoImageView.setImageResource(R.drawable.add);
        Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(
                Toolbar.LayoutParams.WRAP_CONTENT,
                Toolbar.LayoutParams.WRAP_CONTENT
        );
        layoutParams.gravity = android.view.Gravity.END | android.view.Gravity.TOP; // Align to top right corner
        layoutParams.rightMargin = 16; // Set margin to the right
        layoutParams.topMargin = 16; // Set margin from top
        toolbar.addView(logoImageView, layoutParams);

        // Set up logo click listener to show popup menu
        logoImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu(v); // Pass the ImageView as the anchor view
            }
        });

        // Initialize RecyclerView and LayoutManager
        recyclerViewSocieties = findViewById(R.id.recyclerViewSocieties);
        recyclerViewSocieties.setLayoutManager(new LinearLayoutManager(this));

        // Initialize societyList and adapter
        societyList = new ArrayList<>();
        adapter = new SocietyAdapter(societyList);
        recyclerViewSocieties.setAdapter(adapter);

        // Load data into societyList (you can replace this with your own data-loading logic)

        getAllSocieties();
    }

    // Show popup menu
    private void showPopupMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(this, v);

        // Add items to the popup menu
        popupMenu.getMenu().add(0, R.id.action_add_society, 0, "Add Society");
        popupMenu.getMenu().add(0, R.id.action_add_secretary, 0, "Add Secretary");

        // Set up item click listener for popup menu
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.action_add_secretary) {
                    // Start SecretaryActivity when "Add Secretary" is clicked
                    startActivity(new Intent(AdminActivity.this, AddSecretaryActivity.class));
                    Toast.makeText(AdminActivity.this, "Add Secretary clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (id == R.id.action_add_society) {
                    Toast.makeText(AdminActivity.this, "Add Society clicked", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AdminActivity.this, AddSocietyActivity.class));
                    return true;
                }
                return false;
            }
        });

        // Show popup menu
        popupMenu.show();

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        getAllSocieties();
        Log.e("onRestartttttt","ddddddd");
        society_count.setText("Total Socities : " + societyList.size());
    }

    @Override
    protected void onResume() {
        super.onResume();
        getAllSocieties();
        society_count.setText("Total Socities : " + societyList.size());
    }

    public void getAllSocieties(){

        API api = RetrofitClient.getInstance().getApi();
        Call<JsonObject> jsonObjectCall = null;
        jsonObjectCall = api.getSocieties();
        jsonObjectCall.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful() && response.body() != null) {
                    JsonObject body = response.body();
                    if (body.has("status") && body.get("status").getAsString().equals("success")) {
                        JsonArray dataArray = body.getAsJsonArray("data");
                        societyList.clear();

                        for (JsonElement element : dataArray) {
                            JsonObject societyObject = element.getAsJsonObject();
                            String name = societyObject.get("name").getAsString();
                            String address = societyObject.get("address").getAsString();
                            Society society = new Society(name, address);
                            societyList.add(society);
                        }

                        adapter.notifyDataSetChanged();
                        society_count.setText("Total Societies: " + societyList.size());
                    } else {
                        // Handle error response
                        Log.e("API Error", "Unsuccessful response: " + body.toString());
                    }
                } else {
                    // Handle unsuccessful response
                    Log.e("API Error", "Response failed: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("retrofit",t.getLocalizedMessage());
            }
        });
    }

    // Handle back button click
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
