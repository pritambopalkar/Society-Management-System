package com.example.myapplication.Adapter;// OwnerAdapter.java
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
// OwnerViewHolder.java
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;

import com.example.myapplication.Pojo.Owner;

public class OwnerAdapter extends RecyclerView.Adapter<OwnerViewHolder> {
    private Context context;
    private List<Owner> ownerList;

    public OwnerAdapter(Context context, List<Owner> ownerList) {
        this.context = context;
        this.ownerList = ownerList;
    }

    @NonNull
    @Override
    public OwnerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_owner, parent, false);
        return new OwnerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OwnerViewHolder holder, int position) {
        Owner owner = ownerList.get(position);
        holder.textViewName.setText(owner.getName());
        holder.textViewAddress.setText(owner.getAddress());
    }

    @Override
    public int getItemCount() {
        return ownerList.size();
    }
}


