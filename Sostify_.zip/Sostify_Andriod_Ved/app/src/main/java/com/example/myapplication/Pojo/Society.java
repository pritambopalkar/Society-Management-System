package com.example.myapplication.Pojo;


public class Society {
    private String name;
    private String address;

    public Society(String name, String address) {
        this.name = name;
        // You can set a default address or leave it null
        this.address = address;
    }

    // Getter and setter methods for name and address

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Society{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
