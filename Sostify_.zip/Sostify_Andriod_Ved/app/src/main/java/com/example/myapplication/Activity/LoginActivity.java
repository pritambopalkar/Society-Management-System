package com.example.myapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Activity.Owner.OwnerActivity;
import com.example.myapplication.Activity.Secretary.SecretaryActivity;
import com.example.myapplication.Pojo.Credentials;
import com.example.myapplication.R;
import com.example.myapplication.Retro.RetrofitClient;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Spinner spinnerRoles;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        spinnerRoles = findViewById(R.id.spinnerRoles);
        btnLogin = findViewById(R.id.loginButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRoles.setAdapter(adapter);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    private void login() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String role = spinnerRoles.getSelectedItem().toString();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }



        // Here you can implement your authentication logic
        // For now, let's assume credentials are valid
        if (role.equals("Admin")) {
            startActivity(new Intent(LoginActivity.this,AdminActivity.class));
        }  else if (role.equals("Secretary")) {

        Credentials cr=new Credentials(email,password);

            Log.e("rolesecretary",cr.toString());


        RetrofitClient.getInstance().getApi().loginSecretary(cr).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject jsonObject = response.body();
                    if (jsonObject != null && jsonObject.has("status")) {
                        String status = jsonObject.get("status").getAsString();
                        if ("success".equals(status)) {
                            // Login successful, start SecretaryActivity
                            startActivity(new Intent(LoginActivity.this, SecretaryActivity.class));
                        } else {
                            // Login failed, show appropriate message to the user
                            Toast.makeText(LoginActivity.this, "Login failed. Please check your credentials.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Unexpected response format, show error message
                        Toast.makeText(LoginActivity.this, "Unexpected response from server", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Server returned an error response
                    Toast.makeText(LoginActivity.this, "Failed to communicate with server. Please try again later.", Toast.LENGTH_SHORT).show();
                }
            }


            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("rolesecretary", "Error occurred: " + t.getLocalizedMessage());
                Toast.makeText(LoginActivity.this, "Failed to login. Please check your internet connection.", Toast.LENGTH_SHORT).show();
            }

        });
        }else {
            startActivity(new Intent(LoginActivity.this, OwnerActivity.class));
        }

    }


}
