package com.example.myapplication.Pojo;

public class Credentials {
    private String email;
    private String password;

    // Constructor
    public Credentials(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Getters and Setters
    public String getUsername() {
        return email;
    }

    public void setUsername(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Override toString() method
    @Override
    public String toString() {
        return "Credentials{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
