package com.example.myapplication.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class AnnouncementAdapter extends RecyclerView.Adapter<AnnouncementAdapter.AnnouncementViewHolder> {

    private ArrayList<String> dataSet; // Updated to ArrayList

    // Constructor to initialize the data set
    public AnnouncementAdapter(ArrayList<String> dataSet) {
        this.dataSet = dataSet;
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public AnnouncementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_announcement, parent, false);
        return new AnnouncementViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull AnnouncementViewHolder holder, int position) {
        // Get element from your data set at this position
        // Replace it with the content of the view
        holder.textView.setText(dataSet.get(position)); // Use get() method for ArrayList
    }

    // Return the size of your data set (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return dataSet.size(); // Use size() method for ArrayList
    }

    // Provide a reference to the views for each data item
    public static class AnnouncementViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        public AnnouncementViewHolder(View view) {
            super(view);
            textView = view.findViewById(R.id.textView);
        }
    }
}
