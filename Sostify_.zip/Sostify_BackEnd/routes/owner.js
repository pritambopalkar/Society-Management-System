const express = require("express");
const router = express.Router();
const db = require("../db");
const utils = require("../utils");
const crypto = require("crypto-js");
const jwt = require("jsonwebtoken");
const config = require("../config");
const { token } = require("morgan");

router.post("/registerOwner", (req, res) => {
    const { secretary_id, flat_no, name, address, mobile_no, email, password } = req.body;

    if (!secretary_id || !flat_no || !name || !address || !mobile_no || !email || !password) {
        return res.status(400).json({ error: "One or more required fields are missing" });
    }

    const currentTimestamp = new Date().toISOString().slice(0, 19).replace("T", " ");
    const encryptedPassword = String(crypto.SHA256(password));

    const insertQuery = `
        INSERT INTO owner (secretary_id, flat_no, name, address, mobile_no, email, password, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.execute(insertQuery, [secretary_id, flat_no, name, address, mobile_no, email, encryptedPassword, currentTimestamp], (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        res.json({ message: "Owner registered successfully" });
    });
});

router.post("/loginOwner", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    const encryptedPassword = String(crypto.SHA256(password));

    const selectQuery = `
        SELECT * FROM owner
        WHERE email = ? AND password = ?
    `;

    db.execute(selectQuery, [email, encryptedPassword], (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.length === 0) {
            return res.status(401).json({ error: "Invalid email or password" });
        }

        const user = results[0];
        const payload = {
            id: user.id,
            name: user.name,
            email: user.email  
        };

        try {
            const jwtToken = jwt.sign(payload, config.secret);
            console.log("JWT Token:", jwtToken);
            res.json({ message: "Login successful", user, token: jwtToken }); 
        } catch (error) {
            console.error("JWT Generation Error:", error);
            return res.status(500).json({ error: "JWT Generation Error" });
        }
    });
});

router.put("/updateOwner/:id", (req, res) => {
    const ownerId = req.params.id;
    const { secretary_id, flat_no, name, address, mobile_no, email, password } = req.body;

    if (!secretary_id || !flat_no || !name || !address || !mobile_no || !email || !password) {
        return res.status(400).json({ error: "One or more required fields are missing" });
    }

    const currentTimestamp = new Date().toISOString().slice(0, 19).replace("T", " ");
    const encryptedPassword = String(crypto.SHA256(password));

    const updateQuery = `
        UPDATE owner
        SET secretary_id = ?, flat_no = ?, name = ?, address = ?, mobile_no = ?, email = ?, password = ?, created_at = ?
        WHERE id = ?
    `;

    db.execute(updateQuery, [secretary_id, flat_no, name, address, mobile_no, email, encryptedPassword, currentTimestamp, ownerId], (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ error: "Owner not found" });
        }

        res.json({ message: "Owner details updated successfully" });
    });
});

router.get("/owners", (req, res) => {
    const selectQuery = `
        SELECT * FROM owner
    `;

    db.query(selectQuery, (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        res.json({ owners: results });
    });
});

router.get("/getOwnerById/:id", (req, res) => {
    const ownerId = req.params.id;

    const selectQuery = `
        SELECT * FROM owner
        WHERE id = ?
    `;

    db.query(selectQuery, [ownerId], (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: "Owner not found" });
        }

        res.json({ owner: results[0] });
    });
});

router.delete("/deleteOwner/:id", (req, res) => {
    const ownerId = req.params.id;

    const deleteQuery = `
        DELETE FROM owner
        WHERE id = ?
    `;

    db.query(deleteQuery, [ownerId], (error, results) => {
        if (error) {
            console.error("Database query error:", error);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ error: "Owner not found" });
        }

        res.json({ message: "Owner deleted successfully" });
    });
});








module.exports = router;
