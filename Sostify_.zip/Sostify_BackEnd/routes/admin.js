const express = require("express");
const router = express.Router();
const db = require("../db");
const utils = require("../utils");
const crypto = require("crypto-js");
const jwt = require("jsonwebtoken");
const config = require("../config");
const { token } = require("morgan");

router.get("/fetchAdmin", (req, res) => {
  db.query("SELECT * FROM admin", (error, results, fields) => {
      if (error) {
          console.error("Database query error:", error);
          return res.status(500).json(utils.createErrorResponse("Internal Server Error"));
      }

      if (results.length === 0) {
          return res.status(404).json(utils.createErrorResponse("No data found"));
      }

      const tuples = results.map((row) => Object.values(row));
      res.json(utils.createResponse(error, results));
      res.json(utils.createSuccessResponse("Fetched all admins successfully", tuples));
  });
});

router.post("/registerAdmin", (req, res) => {
  const { name, email, mobile_no, password } = req.body;

  if (!name || !password || !mobile_no || !email) {
    return res.status(400).send(utils.createErrorResponse("Missing required fields"));
  }

  
  const currentTimestamp = new Date().toISOString().slice(0, 19).replace("T", " ");

  const encryptedPassword = String(crypto.SHA256(password));

  const insertQuery = `
    INSERT INTO admin (name, email, mobile_no, password, last_login_at)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.execute(insertQuery, [name, email, mobile_no, encryptedPassword, currentTimestamp], (error, results, fields) => {
    if (error) {
      console.error("Database query error:", error);
      return res.status(500).send(utils.createErrorResponse("Internal Server Error"));
    }

    // Check if any rows were affected by the insertion
    if (results.affectedRows === 0) {
      return res.status(500).send(utils.createErrorResponse("Failed to insert data"));
    }

    res.send(utils.createSuccessResponse("Data inserted successfully"));
  });
});

router.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).send({ message: "Please provide the email and password" });
  }

  const statement = "SELECT id, name, email, password FROM admin WHERE email = ? AND password = ?";

  const encryptedPassword = String(crypto.SHA256(password));

  db.execute(statement, [email, encryptedPassword], (error, results) => {
    if (error) {
      console.error("Database query error:", error);
      return res.status(500).send(utils.createErrorResponse("Internal Server Error"));
    }

    console.log(results); // Log the results for debugging purposes

    if (results.length === 0) {
      return res.status(401).send({ message: "Invalid email or password" });
    }

    const user = results[0];
    const payload = {
      id: user.id,
      name: user.name,
      email: user.email,
    };

    const jwtToken = jwt.sign(payload, config.secret);

    res.send(utils.createSuccessResponse({ token: jwtToken, name: user.name }));
  });
});

// router.put("/updateAdmin/:id", (req, res) => {
//   const adminId = req.params.id;
//   const { name, email, mobile_no, password } = req.body;

//   if (!name || !password || !mobile_no || !email) {
//     return res.status(400).send(utils.createErrorResponse("Missing required fields"));
//   }

//   const currentTimestamp = new Date().toISOString().slice(0, 19).replace("T", " ");

//   const encryptedPassword = String(crypto.SHA256(password));

//   const updateQuery = `
//     UPDATE admin
//     SET name = ?, email = ?, mobile_no = ?, password = ?, last_login_at = ?
//     WHERE id = ?
//   `;

//   db.execute(
//     updateQuery,
//     [name, email, mobile_no, encryptedPassword, currentTimestamp, adminId],
//     (error, results, fields) => {
//       if (error) {
//         console.error("Database query error:", error);
//         return res.status(500).send(utils.createErrorResponse("Internal Server Error"));
//       }

//       if (results.affectedRows === 0) {
//         return res.status(404).send(utils.createErrorResponse("Admin not found"));
//       }

//       res.send(utils.createResponse(error, results));
//       res.send(utils.createSuccessResponse("Data updated successfully"));
//     }
//   );
// });

const verifyToken = (req, res, next) => {
  const token = req.header('Authorization');

  if (!token) {
    return res.status(401).send({ message: 'Unauthorized - Missing token' });
  }

  try {
    const decoded = jwt.verify(token, config.secret);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).send({ message: 'Unauthorized - Invalid token' });
  }
};
router.post("/logout", verifyToken, (req, res) => {
    if (!req.token) {
        return res.status(401).send(utils.createErrorResponse('Unauthorized - Missing token'));
    }
    res.send(utils.createSuccessResponse({ message: 'Logout successful' }));
});


module.exports = router;


