const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const utils = require("./utils");
const db = require("./db");
const jwt = require("jsonwebtoken");
const config = require("./config");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("combined"));

app.get("/version", (req, res) => {
  // Handle the route logic here
  res.send(utils.createSuccessResponse("1.0"));
});

//Check if token is required
app.use((req, res, next) => {
  const skipTokenUrls = [
    "/admin/registerAdmin",
    "/admin/login",
    "/secretary/registerSecretary",
    "/secretary/loginSecretary",
    "/owner/registerOwner",
    "/owner/loginOwner"
  ];

  if (
    skipTokenUrls.findIndex((item) => {
      return req.url.startsWith(item);
    }) != -1
  ) {
    //skip the token check
    next();
  } else {
    const token = req.headers["token"];
    console.log(`token : ${token}`);
    if (!token) {
      res.send(utils.createErrorResponse("missing the token"));
    } else {
      try {
        //try validating token
        const payload = jwt.verify(token, config.secret);

        // add payload details to the request
        req.user = {
          id: payload["id"],
          name: payload["name"],
          email: payload["email"],
        };

        next();
      } catch (ex) {
        console.log(ex)
        res.send(utils.createErrorResponse("invalid token"));
      }
    }
  }
});

// Add Required routes
const adminRouter = require("./routes/admin");
const secretaryRouter = require("./routes/Secretary");
const societyRouter = require("./routes/society");
const amenitiesRouter = require("./routes/amenities");
const servicesRouter = require("./routes/services");
const announcementRouter = require("./routes/announcements.js")
const ownerRouter = require("./routes/owner")

app.use("/admin", adminRouter);
app.use("/secretary", secretaryRouter);
app.use("/society", societyRouter);
app.use("/amenities", amenitiesRouter);
app.use("/services", servicesRouter);
app.use("/announcements", announcementRouter)
app.use("/owner", ownerRouter)

const PORT = 9898;
app.listen(PORT, () => {
  console.log(`Server is running on http://51.210.156.152:${PORT}`);
});